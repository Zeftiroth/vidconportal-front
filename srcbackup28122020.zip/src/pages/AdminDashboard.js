import React from "react";

function AdminDashboard() {
  return <div>This is the admin dashboard page</div>;
}

export default AdminDashboard;
